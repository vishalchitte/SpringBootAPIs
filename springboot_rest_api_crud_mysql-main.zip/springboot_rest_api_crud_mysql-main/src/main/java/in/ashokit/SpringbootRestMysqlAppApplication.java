package in.ashokit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRestMysqlAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestMysqlAppApplication.class, args);
	}

}
