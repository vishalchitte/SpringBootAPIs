package in.ashokit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRestMysqlAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
